package br.com.fatecpg.Agenda;

import java.util.HashMap;

/**
 *
 * @author marques
 */
public class Banco {
    private static HashMap <String, Cliente> cliente;
    public static HashMap<String, Cliente> getCliente(){
    if(cliente==null){
    cliente=new HashMap<>();
    }   
    return cliente;
    }
    
    private static HashMap <String, Fornecedor> fornecedor;
    public static HashMap<String, Fornecedor> getFornecedor(){
    if(fornecedor==null){
    fornecedor=new HashMap<>();
    }   
    return fornecedor;
    }

}
